package it.tr5150.mobile;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.*;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;
import java.util.zip.*;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private File dbFile;
    private Uri pendingPhotoUri;

    private final ActivityResultLauncher<ScanOptions> barcodeLauncher =
        registerForActivityResult(new ScanContract(), result -> {
            if (result.getContents() != null) callJs("onBarcode", result.getContents());
        });

    private final ActivityResultLauncher<Intent> importDbLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if(result.getResultCode()== Activity.RESULT_OK && result.getData()!=null){
                Uri uri=result.getData().getData();
                if(uri!=null) importDatabaseFromUri(uri);
            }
        });

    private final ActivityResultLauncher<Intent> cameraLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if(result.getResultCode()==Activity.RESULT_OK && pendingPhotoUri!=null) runOcr(pendingPhotoUri);
        });

    @SuppressLint("SetJavaScriptEnabled")
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        ensureDatabase();
        webView=new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new DbBridge(),"AndroidDB");
        webView.addJavascriptInterface(new ScannerBridge(),"AndroidScanner");
        webView.addJavascriptInterface(new ExportBridge(),"AndroidExport");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void ensureDatabase(){
        File dir=getDatabasePath("tr5150.db").getParentFile();
        if(dir!=null && !dir.exists()) dir.mkdirs();
        dbFile=getDatabasePath("tr5150.db");
        if(!dbFile.exists()){
            try(InputStream in=getAssets().open("tr5150_seed.db");
                OutputStream out=new FileOutputStream(dbFile)){
                byte[] buf=new byte[8192]; int n;
                while((n=in.read(buf))>0) out.write(buf,0,n);
            }catch(Exception e){throw new RuntimeException(e);}
        }
    }

    public class DbBridge {
        @JavascriptInterface public String getInfo(){
            try(SQLiteDatabase db=SQLiteDatabase.openDatabase(dbFile.getPath(),null,SQLiteDatabase.OPEN_READONLY)){
                String ver="?"; long cnt=0;
                try(Cursor c=db.rawQuery("SELECT value FROM meta WHERE key='version'",null)){if(c.moveToFirst())ver=c.getString(0);}
                try(Cursor c=db.rawQuery("SELECT COUNT(*) FROM items",null)){if(c.moveToFirst())cnt=c.getLong(0);}
                return "Versione "+ver+" · "+cnt+" articoli · offline";
            }catch(Exception e){return "Database non disponibile";}
        }

        @JavascriptInterface public String search(String q,int limit){
            JSONArray arr=new JSONArray();
            if(limit<1||limit>2000)limit=500;
            String sql;
            String[] args;
            q=q==null?"":q.trim();
            if(q.isEmpty()){
                sql="SELECT id,nsn,niin,fsc,nomenclature_en,nomenclature_it,part_number,unit,category,qty,notes FROM items ORDER BY nsn LIMIT ?";
                args=new String[]{String.valueOf(limit)};
            }else{
                String like="%"+q+"%";
                sql="SELECT id,nsn,niin,fsc,nomenclature_en,nomenclature_it,part_number,unit,category,qty,notes FROM items WHERE "+
                    "nsn LIKE ? OR niin LIKE ? OR fsc LIKE ? OR nomenclature_en LIKE ? OR nomenclature_it LIKE ? OR part_number LIKE ? OR category LIKE ? "+
                    "ORDER BY CASE WHEN nsn=? THEN 0 WHEN niin=? THEN 1 ELSE 2 END, nsn LIMIT ?";
                args=new String[]{like,like,like,like,like,like,like,q,q,String.valueOf(limit)};
            }
            try(SQLiteDatabase db=SQLiteDatabase.openDatabase(dbFile.getPath(),null,SQLiteDatabase.OPEN_READONLY);
                Cursor c=db.rawQuery(sql,args)){
                while(c.moveToNext()){
                    JSONObject o=new JSONObject();
                    o.put("id",c.getLong(0));o.put("nsn",nz(c.getString(1)));o.put("niin",nz(c.getString(2)));
                    o.put("fsc",nz(c.getString(3)));o.put("nomenclature_en",nz(c.getString(4)));o.put("nomenclature_it",nz(c.getString(5)));
                    o.put("part_number",nz(c.getString(6)));o.put("unit",nz(c.getString(7)));o.put("category",nz(c.getString(8)));
                    o.put("qty",c.getInt(9));o.put("notes",nz(c.getString(10)));arr.put(o);
                }
            }catch(Exception e){}
            return arr.toString();
        }

        @JavascriptInterface public void updateQty(long id,int qty){
            try(SQLiteDatabase db=SQLiteDatabase.openDatabase(dbFile.getPath(),null,SQLiteDatabase.OPEN_READWRITE)){
                ContentValues cv=new ContentValues();cv.put("qty",qty);db.update("items",cv,"id=?",new String[]{String.valueOf(id)});
            }
        }

        @JavascriptInterface public void importDatabase(){
            runOnUiThread(()->{
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.setType("*/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
                importDbLauncher.launch(i);
            });
        }

        @JavascriptInterface public void downloadDatabase(String url){
            new Thread(()->{
                File tmp=new File(getCacheDir(),"db_download.tmp");
                try{
                    URL u=new URL(url);
                    HttpsURLConnection c=(HttpsURLConnection)u.openConnection();
                    c.setConnectTimeout(15000);c.setReadTimeout(60000);c.connect();
                    if(c.getResponseCode()<200||c.getResponseCode()>=300)throw new IOException("HTTP "+c.getResponseCode());
                    try(InputStream in=c.getInputStream();OutputStream out=new FileOutputStream(tmp)){
                        byte[] b=new byte[16384];int n;while((n=in.read(b))>0)out.write(b,0,n);
                    }
                    if(!isValidDb(tmp))throw new IOException("Database non valido");
                    replaceDb(tmp);
                    callJs("onDatabaseChanged","Database aggiornato correttamente");
                }catch(Exception e){callJs("onDatabaseChanged","Errore aggiornamento: "+e.getMessage());}
            }).start();
        }
    }

    public class ScannerBridge {
        @JavascriptInterface public void scanBarcode(){
            runOnUiThread(()->{
                ScanOptions o=new ScanOptions();o.setPrompt("Inquadra barcode o QR");o.setBeepEnabled(true);o.setOrientationLocked(true);
                barcodeLauncher.launch(o);
            });
        }
        @JavascriptInterface public void scanText(){
            runOnUiThread(()->{
                try{
                    File f=File.createTempFile("ocr_",".jpg",getCacheDir());
                    pendingPhotoUri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".fileprovider",f);
                    Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    i.putExtra(MediaStore.EXTRA_OUTPUT,pendingPhotoUri);
                    i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    cameraLauncher.launch(i);
                }catch(Exception e){Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();}
            });
        }
    }

    public class ExportBridge {
        @JavascriptInterface public void exportRows(String format,String rowsJson){
            new Thread(()->{
                try{
                    JSONArray rows=new JSONArray(rowsJson);
                    File out;
                    switch(format.toLowerCase(Locale.ROOT)){
                        case "pdf": out=exportPdf(rows); break;
                        case "docx": out=exportDocx(rows); break;
                        case "xlsx": out=exportXlsx(rows); break;
                        default: out=exportCsv(rows); break;
                    }
                    shareFile(out);
                }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"Errore export: "+e.getMessage(),Toast.LENGTH_LONG).show());}
            }).start();
        }
    }

    private void importDatabaseFromUri(Uri uri){
        new Thread(()->{
            try{
                File tmp=new File(getCacheDir(),"db_import.tmp");
                try(InputStream in=getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(tmp)){
                    byte[] b=new byte[16384];int n;while((n=in.read(b))>0)out.write(b,0,n);
                }
                if(!isValidDb(tmp))throw new IOException("File SQLite non valido o tabella items mancante");
                replaceDb(tmp); callJs("onDatabaseChanged","Database importato correttamente");
            }catch(Exception e){callJs("onDatabaseChanged","Errore importazione: "+e.getMessage());}
        }).start();
    }

    private boolean isValidDb(File f){
        try(SQLiteDatabase db=SQLiteDatabase.openDatabase(f.getPath(),null,SQLiteDatabase.OPEN_READONLY);
            Cursor c=db.rawQuery("SELECT nsn,nomenclature_en,qty FROM items LIMIT 1",null)){return true;}
        catch(Exception e){return false;}
    }
    private synchronized void replaceDb(File src)throws IOException{
        File bak=new File(dbFile.getPath()+".bak");
        if(dbFile.exists())copy(dbFile,bak);
        try{copy(src,dbFile);}
        catch(Exception e){if(bak.exists())copy(bak,dbFile);throw e;}
        if(bak.exists())bak.delete();
    }
    private void runOcr(Uri uri){
        try{
            InputImage image=InputImage.fromFilePath(this,uri);
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                .addOnSuccessListener(t->{
                    String full=t.getText();
                    String selected=pickNumber(full);
                    callJs2("onOcr",full,selected);
                })
                .addOnFailureListener(e->callJs2("onOcr","Errore OCR: "+e.getMessage(),""));
        }catch(Exception e){callJs2("onOcr","Errore OCR: "+e.getMessage(),"");}
    }
    private String pickNumber(String s){
        Pattern p=Pattern.compile("\\b\\d{4}[- ]?\\d{2}[- ]?\\d{3}[- ]?\\d{4}\\b");
        Matcher m=p.matcher(s); if(m.find())return m.group().replace(' ','-');
        Pattern p2=Pattern.compile("\\b\\d{13}\\b"); Matcher m2=p2.matcher(s);
        if(m2.find()){String x=m2.group();return x.substring(0,4)+"-"+x.substring(4,6)+"-"+x.substring(6,9)+"-"+x.substring(9);}
        Pattern p3=Pattern.compile("\\b[A-Z0-9][A-Z0-9._/-]{4,24}\\b",Pattern.CASE_INSENSITIVE);
        Matcher m3=p3.matcher(s);return m3.find()?m3.group():"";
    }
    private void callJs(String fn,String a){
        runOnUiThread(()->webView.evaluateJavascript("window."+fn+"("+JSONObject.quote(a)+")",null));
    }
    private void callJs2(String fn,String a,String b){
        runOnUiThread(()->webView.evaluateJavascript("window."+fn+"("+JSONObject.quote(a)+","+JSONObject.quote(b)+")",null));
    }
    private static String nz(String s){return s==null?"":s;}
    private static void copy(File a,File b)throws IOException{
        try(InputStream in=new FileInputStream(a);OutputStream out=new FileOutputStream(b)){
            byte[] buf=new byte[16384];int n;while((n=in.read(buf))>0)out.write(buf,0,n);
        }
    }

    private File exportCsv(JSONArray rows)throws Exception{
        File f=new File(getCacheDir(),"TR5150_export.csv");
        try(Writer w=new OutputStreamWriter(new FileOutputStream(f),StandardCharsets.UTF_8)){
            w.write("NSN;NIIN;FSC;NOMENCLATURA INGLESE;NOMENCLATURA ITALIANA;PART NUMBER;UNITA;CATEGORIA;QTY;NOTE\\n");
            for(int i=0;i<rows.length();i++){JSONObject o=rows.getJSONObject(i);
                w.write(csv(o.optString("nsn"))+";"+csv(o.optString("niin"))+";"+csv(o.optString("fsc"))+";"+
                    csv(o.optString("nomenclature_en"))+";"+csv(o.optString("nomenclature_it"))+";"+csv(o.optString("part_number"))+";"+
                    csv(o.optString("unit"))+";"+csv(o.optString("category"))+";"+o.optInt("qty")+";"+csv(o.optString("notes"))+"\\n");
            }
        } return f;
    }
    private String csv(String s){return "\""+s.replace("\"","\"\"")+"\"";}

    private File exportPdf(JSONArray rows)throws Exception{
        File f=new File(getCacheDir(),"TR5150_export.pdf");
        PdfDocument pdf=new PdfDocument(); Paint p=new Paint();p.setTextSize(9);
        int pageNo=1,y=35;PdfDocument.Page page=newPdfPage(pdf,pageNo);Canvas c=page.getCanvas();
        for(int i=0;i<rows.length();i++){
            if(y>800){pdf.finishPage(page);page=newPdfPage(pdf,++pageNo);c=page.getCanvas();y=35;}
            JSONObject o=rows.getJSONObject(i);
            c.drawText(o.optString("nsn")+"  "+o.optString("nomenclature_it")+"  QTY:"+o.optInt("qty"),25,y,p);y+=16;
            c.drawText(o.optString("nomenclature_en"),25,y,p);y+=20;
        }
        pdf.finishPage(page);try(OutputStream out=new FileOutputStream(f)){pdf.writeTo(out);}pdf.close();return f;
    }
    private PdfDocument.Page newPdfPage(PdfDocument pdf,int n){return pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,n).create());}

    private File exportDocx(JSONArray rows)throws Exception{
        File f=new File(getCacheDir(),"TR5150_export.docx");
        try(ZipOutputStream z=new ZipOutputStream(new FileOutputStream(f))){
            zipText(z,"[Content_Types].xml","<?xml version=\"1.0\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>");
            zipText(z,"_rels/.rels","<?xml version=\"1.0\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>");
            StringBuilder b=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>");
            for(int i=0;i<rows.length();i++){JSONObject o=rows.getJSONObject(i);
                String line=o.optString("nsn")+" | "+o.optString("nomenclature_en")+" | "+o.optString("nomenclature_it")+" | QTY "+o.optInt("qty");
                b.append("<w:p><w:r><w:t>").append(xml(line)).append("</w:t></w:r></w:p>");
            }
            b.append("</w:body></w:document>");zipText(z,"word/document.xml",b.toString());
        }return f;
    }

    private File exportXlsx(JSONArray rows)throws Exception{
        File f=new File(getCacheDir(),"TR5150_export.xlsx");
        try(ZipOutputStream z=new ZipOutputStream(new FileOutputStream(f))){
            zipText(z,"[Content_Types].xml","<?xml version=\"1.0\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>");
            zipText(z,"_rels/.rels","<?xml version=\"1.0\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
            zipText(z,"xl/workbook.xml","<?xml version=\"1.0\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"TR5150\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
            zipText(z,"xl/_rels/workbook.xml.rels","<?xml version=\"1.0\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>");
            String[] heads={"NSN","NIIN","FSC","NOMENCLATURA INGLESE","NOMENCLATURA ITALIANA","PART NUMBER","UNITA","CATEGORIA","QTY","NOTE"};
            StringBuilder s=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>");
            s.append("<row r=\"1\">");for(int j=0;j<heads.length;j++)s.append(cell(j,1,heads[j]));s.append("</row>");
            for(int i=0;i<rows.length();i++){JSONObject o=rows.getJSONObject(i);int rr=i+2;
                String[] v={o.optString("nsn"),o.optString("niin"),o.optString("fsc"),o.optString("nomenclature_en"),o.optString("nomenclature_it"),o.optString("part_number"),o.optString("unit"),o.optString("category"),String.valueOf(o.optInt("qty")),o.optString("notes")};
                s.append("<row r=\"").append(rr).append("\">");for(int j=0;j<v.length;j++)s.append(cell(j,rr,v[j]));s.append("</row>");
            }
            s.append("</sheetData></worksheet>");zipText(z,"xl/worksheets/sheet1.xml",s.toString());
        }return f;
    }
    private String cell(int col,int row,String value){
        StringBuilder x=new StringBuilder();int n=col+1;while(n>0){int r=(n-1)%26;x.insert(0,(char)('A'+r));n=(n-1)/26;}
        return "<c r=\""+x+row+"\" t=\"inlineStr\"><is><t>"+xml(value)+"</t></is></c>";
    }
    private void zipText(ZipOutputStream z,String name,String text)throws Exception{
        z.putNextEntry(new ZipEntry(name));z.write(text.getBytes(StandardCharsets.UTF_8));z.closeEntry();
    }
    private String xml(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");}
    private void shareFile(File f){
        runOnUiThread(()->{
            Uri u=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);
            Intent i=new Intent(Intent.ACTION_SEND);i.setType("*/*");i.putExtra(Intent.EXTRA_STREAM,u);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i,"Salva o condividi"));
        });
    }
}
