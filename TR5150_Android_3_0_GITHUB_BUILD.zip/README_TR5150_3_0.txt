TR5150 ANDROID 3.0 — PROGETTO

Versione: 3.0
Database iniziale incluso: 82 articoli
Database: SQLite separato dall'APK a runtime.

FUNZIONI IMPLEMENTATE
- Ricerca offline per NSN, NIIN, FSC, nomenclatura inglese/italiana, Part Number, categoria
- Quantità QTY con:
  0–4 = rosso
  5–20 = normale
  >20 = verde
- Scanner barcode/QR
- OCR da fotocamera ("LEGGI NUMERO"):
  riconosce testo stampato e prova a estrarre automaticamente un NSN
- Database separato:
  * copia del database iniziale al primo avvio
  * IMPORTA DB DA FILE
  * SCARICA/AGGIORNA DB da URL HTTPS
  * validazione del database prima della sostituzione
- Export dei risultati:
  * PDF
  * Word DOCX
  * Excel XLSX
  * CSV
- Condivisione/salvataggio tramite pannello Android

SCHEMA DATABASE
Tabella: items
id, nsn, niin, fsc, nomenclature_en, nomenclature_it,
part_number, unit, category, qty, notes

IMPORTANTE
L'URL per l'aggiornamento non è fissato nel codice: si inserisce nell'app.
Quando avremo un file completo FED LOG/WebFLIS autorizzato, potremo creare
un database SQLite molto più grande mantenendo la stessa app.

COMPILAZIONE
Aprire questa cartella con Android Studio.
Attendere il Gradle Sync.
Build > Build App Bundle(s) / APK(s) > Build APK(s).

L'APK di debug si troverà normalmente in:
app/build/outputs/apk/debug/app-debug.apk
